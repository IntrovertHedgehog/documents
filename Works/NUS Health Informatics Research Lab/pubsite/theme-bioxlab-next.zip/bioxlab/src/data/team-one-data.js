const team_one_data = [
  {
    id: 1,
    img: "/assets/img/team/team-thumb-05.png",
    name: "Cameron Williamson",
    title: "Genetic Specialist",
  },

  {
    id: 2,
    img: "/assets/img/team/team-thumb-06.png",
    name: "Savannah Nguyen",
    title: "Microbiology Expert",
  },
  {
    id: 3,
    img: "/assets/img/team/team-thumb-07.png",
    name: "Darlene Robertson",
    title: "Genetic Specialist",
  },
  {
    id: 4,
    img: "/assets/img/team/team-thumb-08.png",
    name: "Marvin McKinney",
    title: "MEDICAL DOCTOR",
  },
  {
    id: 5,
    img: "/assets/img/team/team-thumb-10.jpg",
    name: "Cameron Williamson",
    title: "Genetic Specialist",
  },
  {
    id: 6,
    img: "/assets/img/team/team-thumb-11.jpg",
    name: "Savannah Nguyen",
    title: "Microbiology Expert",
  },
  {
    id: 7,
    img: "/assets/img/team/team-thumb-12.jpg",
    name: "Darlene Robertson",
    title: "Genetic Specialist",
  },
  {
    id: 8,
    img: "/assets/img/team/team-thumb-13.jpg",
    name: "Marvin McKinney",
    title: "MEDICAL DOCTOR",
  },
];
export default team_one_data;
