const blog_data = [
  {
    id: 1,
    img: "/assets/img/blog/blog-thumb-01.jpg",
    blog_date: (
      <>
        26<span>Dec</span>
      </>
    ),
    blog_category: "Medicine",
    blog_title: (
      <>
        Heart Diseases Tests Ordered <br /> By Doctors
      </>
    ),
    blog_des: (
      <>
        Nam eget dui vel quam sodales semper quis porttitor tortor. Vivamus quis
        ex nulla ...
      </>
    ),
  },
  {
    id: 2,
    img: "/assets/img/blog/blog-thumb-02.jpg",
    blog_date: (
      <>
        26<span>Dec</span>
      </>
    ),
    blog_category: "Medicine",
    blog_title: (
      <>
        Heart Diseases Tests Ordered <br /> By Doctors
      </>
    ),
    blog_des: (
      <>
        Nam eget dui vel quam sodales semper quis porttitor tortor. Vivamus quis
        ex nulla ...
      </>
    ),
  },
  {
    id: 3,
    img: "/assets/img/blog/blog-thumb-03.jpg",
    blog_date: (
      <>
        26<span>Dec</span>
      </>
    ),
    blog_category: "Medicine",
    blog_title: (
      <>
        Identifying bases of disease <br /> pathophysio
      </>
    ),
    blog_des: (
      <>
        Nam eget dui vel quam sodales semper quis porttitor tortor. Vivamus quis
        ex nulla ...
      </>
    ),
  },

  {
    id: 4,
    img: "/assets/img/blog/blog-thumb-04.jpg",
    blog_date: (
      <>
        26<span>Dec</span>
      </>
    ),
    blog_category: "Medicine",
    blog_title: "Coronavirus global health emergency",
    blog_des: (
      <>
        Nam eget dui vel quam sodales semper quis porttitor tortor. Vivamus quis
        ex nulla ...
      </>
    ),
  },
];
export default blog_data;
