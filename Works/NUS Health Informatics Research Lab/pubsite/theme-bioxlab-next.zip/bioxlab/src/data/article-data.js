// article data like this 
const article_data = [
  {
    id: 1,
    img: "/assets/img/blog/blog-in-01.jpg",
    slider_img: [],
    user: "Alextina",
    date: " Dec 28, 2022",
    comments: "(04)Coments",
    views: "1,526 views",
    video: [],
    title: " Lavoratories used for scientic reseach take many froms.",
    des: (
      <>
        Laboratories used for scientific research take many forms because of the
        differing requirements of specialists in the various fields of science
        and engineering. A physics laboratory
      </>
    ),
  },

  {
    id: 2,
    img: "",
    slider_img: [
      {
        img: "/assets/img/blog/blog-in-02.jpg",
      },
      {
        img: "/assets/img/blog/blog-in-01.jpg",
      },
      {
        img: "/assets/img/blog/blog-in-03.jpg",
      },
    ],
    user: "Alextina",
    date: " Dec 28, 2022",
    comments: "(04)Coments",
    views: "1,526 views",
    video: [],
    title: " Lavoratories used for scientic reseach take many froms.",
    des: (
      <>
        Laboratories used for scientific research take many forms because of the
        differing requirements of specialists in the various fields of science
        and engineering. A physics laboratory
      </>
    ),
  },

  {
    id: 3,
    img: "",
    slider_img: [],
    user: "Alextina",
    date: " Dec 28, 2022",
    comments: "(04)Coments",
    views: "1,526 views",
    video: [
      {
        video_tum: "/assets/img/blog/blog-in-03.jpg",
        videoId: "d8w5SICzzxc",
      },
    ],
    title:
      "Four Ways to Fullfill Your Task For Makes Parents Happy and Healthy",
    des: (
      <>
        Compellingly exploit B2B vortals with emerging total linkage.
        Appropriately pursue strategic leadership whe intermandated ideas.
        Proactively revolutionize interoperable {"outside the box"} thinking
        with fully researched innovation. Dramatically facilitate exceptional
        architectures and bricks-and-clicks data. Progressively genera
        extensible e-services for.
      </>
    ),
  },
];

export default article_data;
