const service_two_data = [
  {
    id: 1,
    color: "",
    icon_color: "",
    icon: "flaticon-hemoglobin-test-meter",
    title: "Hemoglobin",
    dot: "",
  },

  {
    id: 2,
    color: "tp-pink-bg",
    icon_color: "tp-pink-icon",
    icon: "flaticon-blood-test",
    title: "Blood Testing",
    dot: "pink-dot",
  },

  {
    id: 3,
    color: "tp-green-bg",
    icon_color: "tp-green-icon",
    icon: "flaticon-bacteria",
    title: "Microbiology",
    dot: "green-dot",
  },

  {
    id: 4,
    color: "tp-sky-bg",
    icon_color: "tp-sky-icon",
    icon: "flaticon-biochemistry",
    title: "Biochemistry",
    dot: "sky-dot",
  },
  {
    id: 5,
    color: "tp-green-bg",
    icon_color: "tp-green-icon",
    icon: "flaticon-heart",
    title: "Genetics",
    dot: "green-dot",
  },
  {
    id: 6,
    color: "tp-sky-bg",
    icon_color: "tp-sky-icon",
    icon: "flaticon-dna",
    title: "Microbiogy",
    dot: "sky-dot",
  },
  {
    id: 7,
    color: "",
    icon_color: "",
    icon: "flaticon-dna-1",
    title: "Histopahtolgy",
    dot: "",
  },
  {
    id: 8,
    color: "tp-pink-bg",
    icon_color: "tp-pink-icon",
    icon: "flaticon-ct-scan",
    title: "Hemoglobin",
    dot: "pink-dot",
  },
];
export default service_two_data;
